﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopSystem
{
    public partial class askForRegister : Form
    {
        public askForRegister()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            askForRegister.ActiveForm.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            askForRegister.ActiveForm.Close();
            Register newReg = new Register();
            newReg.Show();
        
            
        }
    }
}
