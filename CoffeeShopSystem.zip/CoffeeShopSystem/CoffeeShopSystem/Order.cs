﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopSystem
{
    public class Order : Interface1
    {
        private String typeOfCoffee;
        private double price;
        private String sizeOfCoffee;
        private int quantity;
        public String ingredients;

        public Order(String typeOfCoffee, double price, String sizeOfCoffee, int quantity, String ingredients)
        {
            this.typeOfCoffee = typeOfCoffee;
            this.price = price;
            this.sizeOfCoffee = sizeOfCoffee;
            this.quantity = quantity;
            this.ingredients = ingredients;
        }

        public String getTypeOfCoffee()
        {
            return typeOfCoffee;
        }

        public double getPrice()
        {
            return price;
        }

        public String getSizeOfCoffee()
        {
            return sizeOfCoffee;
        }

        public int getQuantity()
        {
            return quantity;
        }

        public String getIngredients()
        {
            return ingredients;
        }

        public void setTypeOfCoffee(String typeOfCoffee)
        {
            this.typeOfCoffee = typeOfCoffee;
        }

        public void setPrice(double price)
        {
            this.price = price;
        }

        public void setSizeOfCoffee(String sizeOfCoffee)
        {
            this.sizeOfCoffee = sizeOfCoffee;
        }

        public void setQuantity(int quantity)
        {
            this.quantity = quantity;
        }

        public void setIngredients(String ingredients)
        {
            this.ingredients = ingredients;
        }

        public virtual double TotalOrderSummary(double price, int quantity)
        {
            double total = price * quantity;
            return total;
        }

        public virtual String TotalOrderSummary()
        {
            return "Qtity                  |Description                     |Price                  |Total\n"
                + this.quantity + "                      " + this.ingredients + "           " + this.price + "            " + TotalOrderSummary(this.price, this.quantity);
        }

        void Interface1.TotalOrderSummary()
        {
            throw new NotImplementedException();
        }
    }
}

