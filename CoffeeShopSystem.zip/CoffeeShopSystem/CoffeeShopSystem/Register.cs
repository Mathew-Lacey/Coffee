﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopSystem
{
    public partial class Register : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");
        public Register()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into ManagerTable(Username, Password_) VALUES(@Username, @Password_)", con);
            cmd.Parameters.AddWithValue("@Username", username_txt.Text);
            cmd.Parameters.AddWithValue("@Password_", password_txt.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("User Registered");
            Register.ActiveForm.Close();
        }
    }
}
