﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace CoffeeShopSystem
{
    public partial class Login : Form
    {
        

        private bool isConnected;

        public Login()
        {
            GC.KeepAlive(this);
            InitializeComponent();

        }


        public bool IsConnected
        {
            get { return this.isConnected; }
            set { this.isConnected = value; }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void confirm_btn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");
            String username, password;

            username = username_txt.Text;
            password = password_txt.Text;


            SqlCommand cmd = new SqlCommand("Select * from ManagerTable where Username like @Username and Password_ = @Password_", con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password_", password);

            con.Open();

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            con.Close();
            bool loginSuccessful = ((ds.Tables.Count > 0) && (ds.Tables[0].Rows.Count > 0));
            if (loginSuccessful)
            {
                
                IsConnected = true;
                MessageBox.Show("Login Successfull");
                Login.ActiveForm.Close();

            }
            else
            {
                askForRegister newReg = new askForRegister();
                newReg.Show();
            }
        }

        private void register_btn_Click(object sender, EventArgs e)
        {
            Register newReg = new Register();
            newReg.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Login.ActiveForm.Close();
            
           
        }
    }
}
