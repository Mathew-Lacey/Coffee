﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopSystem
{
    public class Manager : Order
    {
        public Manager(string typeOfCoffee, double price, string sizeOfCoffee, int quantity, string ingredients) : base(typeOfCoffee, price, sizeOfCoffee, quantity, ingredients)
        {
        }

        public override double TotalOrderSummary(double price, int quantity)
        {
            return base.TotalOrderSummary(price, quantity);
        }

        public override String TotalOrderSummary()
        {
            return base.TotalOrderSummary();
        }

        public void DisplayInfos(int period)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");

            CoffeeShop coffeeShop = new CoffeeShop();


            //daily selected
            if (period == 1)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT date_ ,SUM(Total) as Totals FROM SalesTable WHERE date_ = date_  GROUP BY date_", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                while (sdr.Read())
                {
                    file.WriteLine("========================================= Daily Sales =========================================\n");
                    file.WriteLine("Daily total for: " + sdr["date_"] + "\t Total: " + sdr["Totals"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
            //monthly selected
            if (period == 2)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT DATENAME(MONTH, DateAdd(MONTH, Month(date_), 0) - 1) as monthly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE date_ = date_ GROUP BY MONTH(date_)", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                while (sdr.Read())
                {

                    file.WriteLine("========================================= Monthly Sales =========================================\n");
                    file.WriteLine("Monthly total for: " + sdr["monthly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
            //yearly selected
            if (period == 3)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT Year(date_) as yearly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE date_ = date_ GROUP BY YEAR(date_)", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                while (sdr.Read())
                {

                    file.WriteLine("========================================= Yearly Sales =========================================\n");
                    file.WriteLine("Yearly total for: " + sdr["yearly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
        }

        public void SaveToText(int period)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");

            CoffeeShop coffeeShop = new CoffeeShop();


            //daily selected
            if (period == 1)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT date_ ,SUM(Total) as Totals FROM SalesTable WHERE date_ = date_  GROUP BY date_", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                while (sdr.Read())
                {
                    file.WriteLine("========================================= Daily Sales =========================================\n");
                    file.WriteLine("Daily total for: " + sdr["date_"] + "\t Total: " + sdr["Totals"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
            //monthly selected
            if (period == 2)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT DATENAME(MONTH, DateAdd(MONTH, Month(date_), 0) - 1) as monthly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE date_ = date_ GROUP BY MONTH(date_)", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                while (sdr.Read())
                {

                    file.WriteLine("========================================= Monthly Sales =========================================\n");
                    file.WriteLine("Monthly total for: " + sdr["monthly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
            //yearly selected
            if (period == 3)
            {
                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                SqlCommand cmd = new SqlCommand("SELECT Year(date_) as yearly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE date_ = date_ GROUP BY YEAR(date_)", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                //Daily sales: 'shows daily sales for that day'

                // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                while (sdr.Read())
                {

                    file.WriteLine("========================================= Yearly Sales =========================================\n");
                    file.WriteLine("Yearly total for: " + sdr["yearly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                    file.WriteLine("===============================================================================================");
                }


                sdr.Close();
                con.Close();
                file.Close();

            }
        }


        public void SaveToDB(int Order, String desc, double Price, double total, String date)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");

            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO CoffeeShopeDB.dbo.SalesTable(Quatity, description_, Price, Total, date_) Values (@Quatity, @description_, @Price, @Total, @date_)", con);
            cmd.Parameters.AddWithValue("@Quatity", Order);
            cmd.Parameters.AddWithValue("@description_", desc);
            cmd.Parameters.AddWithValue("@Price", Price);
            cmd.Parameters.AddWithValue("@Total", total);
            cmd.Parameters.AddWithValue("@date_", date);


            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
    
}
