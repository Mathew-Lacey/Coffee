﻿namespace CoffeeShopSystem
{
    partial class CoffeeShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CoffeeShop));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.management_tab = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.display_btn = new System.Windows.Forms.Button();
            this.print_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.order_tab = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.cream_chkBox = new System.Windows.Forms.CheckBox();
            this.sugar_chkBox = new System.Windows.Forms.CheckBox();
            this.large_rdo = new System.Windows.Forms.RadioButton();
            this.medium_rdo = new System.Windows.Forms.RadioButton();
            this.small_rdo = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.printOrder_btn = new System.Windows.Forms.Button();
            this.addOrder_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.tabControl1.SuspendLayout();
            this.management_tab.SuspendLayout();
            this.order_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.management_tab);
            this.tabControl1.Controls.Add(this.order_tab);
            this.tabControl1.Font = new System.Drawing.Font("Century", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(110, 20);
            this.tabControl1.Location = new System.Drawing.Point(-7, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(957, 557);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // management_tab
            // 
            this.management_tab.BackColor = System.Drawing.Color.Transparent;
            this.management_tab.Controls.Add(this.label6);
            this.management_tab.Controls.Add(this.richTextBox1);
            this.management_tab.Controls.Add(this.dateTimePicker1);
            this.management_tab.Controls.Add(this.radioButton3);
            this.management_tab.Controls.Add(this.radioButton2);
            this.management_tab.Controls.Add(this.radioButton1);
            this.management_tab.Controls.Add(this.label5);
            this.management_tab.Controls.Add(this.label4);
            this.management_tab.Controls.Add(this.label2);
            this.management_tab.Controls.Add(this.label3);
            this.management_tab.Controls.Add(this.label1);
            this.management_tab.Controls.Add(this.display_btn);
            this.management_tab.Controls.Add(this.print_btn);
            this.management_tab.Controls.Add(this.save_btn);
            this.management_tab.Controls.Add(this.panel1);
            this.management_tab.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.management_tab.Location = new System.Drawing.Point(4, 24);
            this.management_tab.Name = "management_tab";
            this.management_tab.Padding = new System.Windows.Forms.Padding(3);
            this.management_tab.Size = new System.Drawing.Size(949, 529);
            this.management_tab.TabIndex = 0;
            this.management_tab.Text = "Management";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(551, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "Summary:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(554, 196);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(378, 185);
            this.richTextBox1.TabIndex = 14;
            this.richTextBox1.Text = "";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/mm/yyyy";
            this.dateTimePicker1.Location = new System.Drawing.Point(656, 135);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(276, 23);
            this.dateTimePicker1.TabIndex = 13;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(860, 109);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(70, 20);
            this.radioButton3.TabIndex = 12;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Yearly";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(742, 109);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(82, 20);
            this.radioButton2.TabIndex = 11;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Monthly";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(635, 109);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(62, 20);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Daily";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(869, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Yearly";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(760, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Monthly";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(653, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Daily";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(551, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Sale";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(50, 0, 3, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(330, 20, 0, 0);
            this.label1.Size = new System.Drawing.Size(649, 48);
            this.label1.TabIndex = 5;
            this.label1.Text = "COFFEE SHOP SYSTEM";
            // 
            // display_btn
            // 
            this.display_btn.Image = global::CoffeeShopSystem.Properties.Resources.icons8_view_50;
            this.display_btn.Location = new System.Drawing.Point(355, 211);
            this.display_btn.Name = "display_btn";
            this.display_btn.Size = new System.Drawing.Size(164, 170);
            this.display_btn.TabIndex = 4;
            this.display_btn.UseVisualStyleBackColor = true;
            this.display_btn.Click += new System.EventHandler(this.display_btn_Click);
            // 
            // print_btn
            // 
            this.print_btn.Image = global::CoffeeShopSystem.Properties.Resources.icons8_print_50;
            this.print_btn.Location = new System.Drawing.Point(185, 211);
            this.print_btn.Name = "print_btn";
            this.print_btn.Size = new System.Drawing.Size(164, 170);
            this.print_btn.TabIndex = 3;
            this.print_btn.UseVisualStyleBackColor = true;
            this.print_btn.Click += new System.EventHandler(this.print_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Image = global::CoffeeShopSystem.Properties.Resources.icons8_downloads_folder_50;
            this.save_btn.Location = new System.Drawing.Point(15, 211);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(164, 170);
            this.save_btn.TabIndex = 2;
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Firebrick;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 25);
            this.panel1.TabIndex = 0;
            // 
            // order_tab
            // 
            this.order_tab.BackColor = System.Drawing.Color.Transparent;
            this.order_tab.Controls.Add(this.richTextBox2);
            this.order_tab.Controls.Add(this.label13);
            this.order_tab.Controls.Add(this.comboBox2);
            this.order_tab.Controls.Add(this.cream_chkBox);
            this.order_tab.Controls.Add(this.sugar_chkBox);
            this.order_tab.Controls.Add(this.large_rdo);
            this.order_tab.Controls.Add(this.medium_rdo);
            this.order_tab.Controls.Add(this.small_rdo);
            this.order_tab.Controls.Add(this.label9);
            this.order_tab.Controls.Add(this.label10);
            this.order_tab.Controls.Add(this.label11);
            this.order_tab.Controls.Add(this.label12);
            this.order_tab.Controls.Add(this.printOrder_btn);
            this.order_tab.Controls.Add(this.addOrder_btn);
            this.order_tab.Controls.Add(this.pictureBox1);
            this.order_tab.Controls.Add(this.comboBox1);
            this.order_tab.Controls.Add(this.label8);
            this.order_tab.Controls.Add(this.label7);
            this.order_tab.Controls.Add(this.panel2);
            this.order_tab.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_tab.Location = new System.Drawing.Point(4, 24);
            this.order_tab.Name = "order_tab";
            this.order_tab.Padding = new System.Windows.Forms.Padding(3);
            this.order_tab.Size = new System.Drawing.Size(949, 529);
            this.order_tab.TabIndex = 1;
            this.order_tab.Text = "Order";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.White;
            this.richTextBox2.Location = new System.Drawing.Point(503, 271);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(427, 155);
            this.richTextBox2.TabIndex = 24;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.richTextBox2_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(500, 242);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Order Summary";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox2.Location = new System.Drawing.Point(809, 202);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 22;
            this.comboBox2.Text = "Select Qtity";
            // 
            // cream_chkBox
            // 
            this.cream_chkBox.AutoSize = true;
            this.cream_chkBox.Location = new System.Drawing.Point(691, 206);
            this.cream_chkBox.Name = "cream_chkBox";
            this.cream_chkBox.Size = new System.Drawing.Size(71, 20);
            this.cream_chkBox.TabIndex = 21;
            this.cream_chkBox.Text = "Cream";
            this.cream_chkBox.UseVisualStyleBackColor = true;
            // 
            // sugar_chkBox
            // 
            this.sugar_chkBox.AutoSize = true;
            this.sugar_chkBox.Location = new System.Drawing.Point(584, 206);
            this.sugar_chkBox.Name = "sugar_chkBox";
            this.sugar_chkBox.Size = new System.Drawing.Size(67, 20);
            this.sugar_chkBox.TabIndex = 20;
            this.sugar_chkBox.Text = "Sugar";
            this.sugar_chkBox.UseVisualStyleBackColor = true;
            // 
            // large_rdo
            // 
            this.large_rdo.AutoSize = true;
            this.large_rdo.Location = new System.Drawing.Point(809, 141);
            this.large_rdo.Name = "large_rdo";
            this.large_rdo.Size = new System.Drawing.Size(65, 20);
            this.large_rdo.TabIndex = 19;
            this.large_rdo.Text = "Large";
            this.large_rdo.UseVisualStyleBackColor = true;
            // 
            // medium_rdo
            // 
            this.medium_rdo.AutoSize = true;
            this.medium_rdo.Location = new System.Drawing.Point(691, 141);
            this.medium_rdo.Name = "medium_rdo";
            this.medium_rdo.Size = new System.Drawing.Size(80, 20);
            this.medium_rdo.TabIndex = 18;
            this.medium_rdo.Text = "Medium";
            this.medium_rdo.UseVisualStyleBackColor = true;
            // 
            // small_rdo
            // 
            this.small_rdo.AutoSize = true;
            this.small_rdo.Location = new System.Drawing.Point(584, 141);
            this.small_rdo.Name = "small_rdo";
            this.small_rdo.Size = new System.Drawing.Size(65, 20);
            this.small_rdo.TabIndex = 17;
            this.small_rdo.Text = "Small";
            this.small_rdo.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(818, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Yearly";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(709, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "Monthly";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(602, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "Daily";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(500, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Size:";
            // 
            // printOrder_btn
            // 
            this.printOrder_btn.Location = new System.Drawing.Point(288, 403);
            this.printOrder_btn.Name = "printOrder_btn";
            this.printOrder_btn.Size = new System.Drawing.Size(124, 23);
            this.printOrder_btn.TabIndex = 10;
            this.printOrder_btn.Text = "Print";
            this.printOrder_btn.UseVisualStyleBackColor = true;
            this.printOrder_btn.Click += new System.EventHandler(this.printOrder_btn_Click);
            // 
            // addOrder_btn
            // 
            this.addOrder_btn.Location = new System.Drawing.Point(159, 403);
            this.addOrder_btn.Name = "addOrder_btn";
            this.addOrder_btn.Size = new System.Drawing.Size(108, 23);
            this.addOrder_btn.TabIndex = 9;
            this.addOrder_btn.Text = "Add to order";
            this.addOrder_btn.UseVisualStyleBackColor = true;
            this.addOrder_btn.Click += new System.EventHandler(this.addOrder_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(159, 192);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 180);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Americano",
            "Cappuccino",
            "Espresso",
            "Late",
            "Macchiato"});
            this.comboBox1.Location = new System.Drawing.Point(159, 135);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(253, 24);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.Text = "Select";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 28);
            this.label8.Margin = new System.Windows.Forms.Padding(50, 0, 3, 0);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(330, 20, 0, 0);
            this.label8.Size = new System.Drawing.Size(649, 48);
            this.label8.TabIndex = 6;
            this.label8.Text = "COFFEE SHOP SYSTEM";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "Type of Coffee:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Firebrick;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(943, 25);
            this.panel2.TabIndex = 1;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument1_BeginPrint);
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // CoffeeShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(942, 482);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CoffeeShop";
            this.Text = "COFFEE SHOP";
            this.tabControl1.ResumeLayout(false);
            this.management_tab.ResumeLayout(false);
            this.management_tab.PerformLayout();
            this.order_tab.ResumeLayout(false);
            this.order_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage management_tab;
        private System.Windows.Forms.TabPage order_tab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button display_btn;
        private System.Windows.Forms.Button print_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button printOrder_btn;
        private System.Windows.Forms.Button addOrder_btn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.CheckBox cream_chkBox;
        private System.Windows.Forms.CheckBox sugar_chkBox;
        private System.Windows.Forms.RadioButton large_rdo;
        private System.Windows.Forms.RadioButton medium_rdo;
        private System.Windows.Forms.RadioButton small_rdo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}

