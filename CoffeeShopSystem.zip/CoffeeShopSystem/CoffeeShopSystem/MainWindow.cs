﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CoffeeShopSystem
{
    public partial class CoffeeShop : Form
    {
        Order newOrder = new Order("", 0, "", 0, "");
        Manager newManager = new Manager("", 0, "", 0, "");
 

        

        public CoffeeShop()
        {
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "d/M/yyyy";

        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            richTextBox1.Text = dateTimePicker1.Value.ToString("dddd, MMMMM dd yyyy, HH:mm:ss");
            richTextBox1.AppendText("\n");

        }

        public String returnRichTxt()
        {
            return richTextBox1.Text;
        }

        public String returnDate()
        {
            return dateTimePicker1.Value.ToString("MM-dd-yyyy");
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void print_btn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");
            if (richTextBox1.TextLength != 0)
            {
                if (printDialog1.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                }
            }
            else
            {
                MessageBox.Show("Please enter a date");
            }

        }

        private void addOrder_btn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");


            //checking for cream and sugar and small
            if (small_rdo.Checked && sugar_chkBox.Checked && cream_chkBox.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + sugar_chkBox.Text + " " + small_rdo.Text + " " + comboBox1.Text);
            }
            //checking for cream and sugar and medium
            else if (medium_rdo.Checked && sugar_chkBox.Checked && cream_chkBox.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + sugar_chkBox.Text + " " + medium_rdo.Text + " " + comboBox1.Text);
            }
            //checking for cream and sugar and large
            else if (large_rdo.Checked && sugar_chkBox.Checked && cream_chkBox.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + sugar_chkBox.Text + " " + large_rdo.Text + " " + comboBox1.Text);
            }

            //checking for sugar and small
            else if (sugar_chkBox.Checked && small_rdo.Checked)
            {
                newOrder.setIngredients(sugar_chkBox.Text + " " + small_rdo.Text + " " + comboBox1.Text);

            }
            //checking for sugar and medium
            else if (sugar_chkBox.Checked && medium_rdo.Checked)
            {
                newOrder.setIngredients(sugar_chkBox.Text + " " + medium_rdo.Text + " " + comboBox1.Text);
            }
            //checking for sugar and large
            else if (sugar_chkBox.Checked && large_rdo.Checked)
            {
                newOrder.setIngredients(sugar_chkBox.Text + " " + large_rdo.Text + " " + comboBox1.Text);
            }
            //checking cream and small
            else if (cream_chkBox.Checked && small_rdo.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + small_rdo.Text + " " + comboBox1.Text);
            }
            //checking cream and medium
            else if (cream_chkBox.Checked && medium_rdo.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + medium_rdo.Text + " " + comboBox1.Text);
            }
            //checking for cream and large
            else if (cream_chkBox.Checked && large_rdo.Checked)
            {
                newOrder.setIngredients(cream_chkBox.Text + " " + large_rdo.Text + " " + comboBox1.Text);
            }


            //getting values from database to fill price and total fields
            con.Open();

            SqlCommand cmdCoffeeType = new SqlCommand("Select Coffee_Type, Small_Price, Medium_Price, Large_Price From CoffeePriceTable where Coffee_Type = @Coffee_Type", con);
            cmdCoffeeType.Parameters.AddWithValue("@Coffee_Type", comboBox1.Text);
            SqlDataReader sdrCoffeeType = cmdCoffeeType.ExecuteReader();

            while (sdrCoffeeType.Read())
            {
                if (small_rdo.Checked)
                {
                    newOrder.setPrice(Convert.ToDouble(sdrCoffeeType.GetValue(1)));
                }
                else if (medium_rdo.Checked)
                {
                    newOrder.setPrice(Convert.ToDouble(sdrCoffeeType.GetValue(2)));
                }
                else if (large_rdo.Checked)
                {
                    newOrder.setPrice(Convert.ToDouble(sdrCoffeeType.GetValue(3)));
                }

            }
            con.Close();
            newOrder.setQuantity(comboBox2.SelectedIndex + 1);

            richTextBox2.AppendText(dateTimePicker1.Value.ToString("dddd, MMMMM dd yyyy, HH:mm:ss") + "\n");
            richTextBox2.AppendText("");
            richTextBox2.AppendText(newOrder.TotalOrderSummary() + "\n");


        }

        private int linesPrinted;
        private string[] lines;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int x = e.MarginBounds.Left;
            int y = e.MarginBounds.Top;
            Brush brush = new SolidBrush(richTextBox1.ForeColor);

            while (linesPrinted < lines.Length)
            {
                e.Graphics.DrawString(lines[linesPrinted++],
                    richTextBox1.Font, brush, x, y);
                y += 15;
                if (y >= e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            linesPrinted = 0;
            e.HasMorePages = false;
        }

        private void printOrder_btn_Click(object sender, EventArgs e)
        {
            if (richTextBox2.TextLength != 0)
            {
                newManager.SaveToDB(newOrder.getQuantity(), newOrder.getIngredients(), newOrder.getPrice(), newOrder.TotalOrderSummary(newOrder.getPrice(), newOrder.getQuantity()), dateTimePicker1.Value.ToString("MM-dd-yyyy"));
                MessageBox.Show("Order Successfully Saved");
            }
            else
            {
                MessageBox.Show("No orders have been made.");
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selct = comboBox1.SelectedIndex;
            switch (selct)
            {
                case 0:
                    pictureBox1.Image = Image.FromFile("..\\..\\Resources\\icons8-latte-64.png");
                    break;
                case 1:
                    pictureBox1.Image = Image.FromFile("..\\..\\Resources\\icons8-cappuccino-64.png");
                    break;
                case 2:
                    pictureBox1.Image = Image.FromFile("..\\..\\Resources\\icons8-americano-64.png");
                    break;
                case 3:
                    pictureBox1.Image = Image.FromFile("..\\..\\Resources\\icons8-espresso-64.png");
                    break;
                case 4:
                    pictureBox1.Image = Image.FromFile("..\\..\\Resources\\icons8-latte-macchiato-64.png");
                    break;


            }
        }

        Login newLog = new Login();
        private void save_btn_Click(object sender, EventArgs e)
        {
            

            if (newLog.IsConnected)
            {
                if (radioButton1.Checked)
                {
                    newManager.SaveToText(1);
                }
                else if (radioButton2.Checked)
                {
                    
                    newManager.SaveToText(2);

                }
                else if (radioButton3.Checked)
                {
                    
                    newManager.SaveToText(3);


                }
            }
            else
            {
                
                newLog.Show();
            }

            

        }

        private void printDocument1_BeginPrint(object sender, PrintEventArgs e)
        {
            char[] param = { '\n' };

            if (printDialog1.PrinterSettings.PrintRange == PrintRange.Selection)
            {
                lines = richTextBox1.SelectedText.Split(param);
            }
            else
            {
                lines = richTextBox1.Text.Split(param);
            }

            int i = 0;
            char[] trimParam = { '\r' };
            foreach (string s in lines)
            {
                lines[i++] = s.TrimEnd(trimParam);
            }

        }
        Login newLogin = new Login();

        private void display_btn_Click(object sender, EventArgs e)
           
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=CoffeeShopeDB;Integrated Security=True");

            if (newLogin.IsConnected)
            {

                if (radioButton1.Checked)
                {
                    // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                    StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                    SqlCommand cmd = new SqlCommand("SELECT date_ ,SUM(Total) as Totals FROM SalesTable WHERE date_ = @date_  GROUP BY date_", con);
                    cmd.Parameters.AddWithValue("@date_", dateTimePicker1.Value.ToString("MM-dd-yyyy"));
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                    //Daily sales: 'shows daily sales for that day'

                    while (sdr.Read())
                    {
                        richTextBox1.AppendText("================ Daily Sales ================\n");
                        richTextBox1.AppendText("Daily total for: " + sdr["date_"] + "\t Total: " + sdr["Totals"] + "\n");
                        richTextBox1.AppendText("===========================================\n");
                    }


                    sdr.Close();
                    con.Close();
                    file.Close();
                }
                else if (radioButton2.Checked)
                {
                    CoffeeShop newCoffee = new CoffeeShop();

                    // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                    StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                    SqlCommand cmd = new SqlCommand("SELECT DATENAME(MONTH, DateAdd(MONTH, Month(date_), 0) - 1) as monthly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE MONTH(date_) = MONTH(@date_) GROUP BY MONTH(date_)", con);
                    cmd.Parameters.AddWithValue("@date_", dateTimePicker1.Value.ToString("MM-dd-yyyy"));
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                    //Daily sales: 'shows daily sales for that day'

                    // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                    while (sdr.Read())
                    {

                        richTextBox1.AppendText("================ Monthly Sales ================\n");
                        richTextBox1.AppendText("Monthly total for: " + sdr["monthly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                        richTextBox1.AppendText("===========================================\n");
                    }


                    sdr.Close();
                    con.Close();
                    file.Close();

                }
                else if (radioButton3.Checked)
                {

                    // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter
                    StreamWriter file = new StreamWriter(@"D:\ProgramingInC#Projects\SA\BackupSales.txt", true);

                    SqlCommand cmd = new SqlCommand("SELECT Year(date_) as yearly ,SUM(Total) AS Total_Sales FROM SalesTable WHERE YEAR(date_) = YEAR(@date_) GROUP BY YEAR(date_)", con);
                    cmd.Parameters.AddWithValue("@date_", dateTimePicker1.Value.ToString("MM-dd-yyyy"));
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    //TODO get it to display the total sales of that day by writing a query to get the total sales of that day same for monthly and yearly and display like
                    //Daily sales: 'shows daily sales for that day'

                    // Open the file for write operations.  If exists, it will overwrite due to the "false" parameter


                    while (sdr.Read())
                    {

                        richTextBox1.AppendText("================ Yearly Sales ================\n");
                        richTextBox1.AppendText("Yearly total for: " + sdr["yearly"] + "\t Total: " + sdr["Total_Sales"] + "\n");
                        richTextBox1.AppendText("===========================================\n");
                    }


                    sdr.Close();
                    con.Close();
                    file.Close();
                }
            }
            else
            {
                newLogin.Show();
            }
        }
        public void SetMyCustomFormat()
        {
            // Set the Format type and the CustomFormat string.
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MM";
        }
    }
}
